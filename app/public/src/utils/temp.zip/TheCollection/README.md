# TheCollection

The Collection aims to be a collection of scripts used frequently in Level-Ups.

### Currently Implemented

- CI/CD
- Terraform
- OAuth

### TODO:

- Nothin'!

If you have suggestions or want something added to this repo, make a PR :)